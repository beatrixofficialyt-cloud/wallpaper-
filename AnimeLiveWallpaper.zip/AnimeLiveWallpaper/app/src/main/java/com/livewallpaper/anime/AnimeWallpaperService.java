package com.livewallpaper.anime;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.Choreographer;
import android.view.SurfaceHolder;

import java.io.InputStream;
import java.util.Random;

/**
 * Live wallpaper that animates a single illustration (assets/character.png):
 *  - hair / ribbon / accessory sway via a mesh warp of the ORIGINAL pixels
 *  - occasional blink (eyelid patch tinted from the artwork's own skin colour)
 *  - soft floating particles, gentle warm light + slow light sweep
 *  - gyro/accelerometer parallax between background, character and particles
 *
 * All periodic motion uses whole numbers of cycles per LOOP seconds, so it loops seamlessly.
 */
public class AnimeWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new AnimeEngine();
    }

    // ---- Artwork geometry: coordinates are in pixels of assets/character.png (640 x 358) ----
    static final int SRC_W = 640, SRC_H = 358;

    /** A soft region that sways: hair tips, ribbon ends, loose pills. */
    static final class Zone {
        final float cx, cy, sigma, ampX, ampY, phase;
        final int cycles; // cycles per LOOP
        Zone(float cx, float cy, float sigma, float ampX, float ampY, float phase, int cycles) {
            this.cx = cx; this.cy = cy; this.sigma = sigma;
            this.ampX = ampX; this.ampY = ampY; this.phase = phase; this.cycles = cycles;
        }
    }

    static final Zone[] ZONES = new Zone[] {
        new Zone(255, 28, 26, 5.0f, 2.5f, 0.0f, 5),   // ahoge
        new Zone(335, 22, 16, 3.0f, 1.5f, 1.1f, 6),   // strand held in hand
        new Zone(610, 193, 28, 6.0f, 3.0f, 0.6f, 4),  // long hair, right edge
        new Zone(60, 200, 22, 5.0f, 2.5f, 2.2f, 5),   // left hair strand
        new Zone(105, 285, 30, 6.5f, 3.5f, 3.0f, 4),  // left lower curls
        new Zone(52, 160, 22, 3.5f, 1.8f, 0.3f, 6),   // left tuft
        new Zone(448, 178, 24, 3.5f, 2.0f, 2.7f, 5),  // bow
        new Zone(492, 195, 18, 5.0f, 2.8f, 4.1f, 6),  // ribbon tail
        new Zone(398, 158, 14, 2.5f, 1.5f, 5.0f, 5),  // heart ribbon
        new Zone(15, 250, 14, 2.0f, 1.5f, 1.7f, 6),   // pill left
        new Zone(557, 175, 14, 2.0f, 1.5f, 3.6f, 5),  // pill right
        new Zone(140, 335, 14, 2.0f, 1.5f, 0.9f, 4),  // pill bottom
    };

    // Eye (for blinking), artwork pixels
    static final float EYE_X = 225f, EYE_Y = 141f, EYE_A = 9.5f, EYE_B = 17f, EYE_TILT = 5f;
    // Where to sample a patch of skin colour for the eyelid
    static final int SKIN_X = 240, SKIN_Y = 166;

    static final double LOOP = 24.0;      // seconds; every cycle count above divides this
    static final double TWO_PI = Math.PI * 2.0;
    static final int MESH_W = 40, MESH_H = 24;

    static final String PREFS = "anime_wallpaper";
    static final String KEY_MODE = "mode";   // 0 = fit, 1 = zoom

    class AnimeEngine extends Engine implements SensorEventListener {

        private final Choreographer.FrameCallback frameCb = new Choreographer.FrameCallback() {
            @Override public void doFrame(long frameTimeNanos) {
                drawFrame();
                if (visible) Choreographer.getInstance().postFrameCallback(this);
            }
        };

        private boolean visible = false;
        private boolean useHwCanvas = Build.VERSION.SDK_INT >= 26;
        private int W = 0, H = 0;
        private int mode = 0;
        private final long t0 = SystemClock.uptimeMillis();

        // bitmaps / paints
        private Bitmap fg, bg, sprite;
        private final Paint fgPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        private final Paint bgPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        private final Paint partPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint glowPaint = new Paint();
        private final Paint sweepPaint = new Paint();
        private final Paint eyePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint lashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private LinearGradient sweepShader;
        private final Matrix sweepMatrix = new Matrix();
        private float sweepBandW;
        private int skinColor = 0xFFF7E6DA;

        // mesh
        private final float[] baseX = new float[(MESH_W + 1) * (MESH_H + 1)];
        private final float[] baseY = new float[(MESH_W + 1) * (MESH_H + 1)];
        private final float[][] weights = new float[ZONES.length][(MESH_W + 1) * (MESH_H + 1)];
        private final float[] verts = new float[(MESH_W + 1) * (MESH_H + 1) * 2];
        private final float[] zdx = new float[ZONES.length];
        private final float[] zdy = new float[ZONES.length];

        // particles
        private static final int N_PART = 34;
        private final float[] pX = new float[N_PART], pY = new float[N_PART], pDepth = new float[N_PART],
                pSwayA = new float[N_PART], pPhase = new float[N_PART], pTw = new float[N_PART];
        private final int[] pRise = new int[N_PART], pSwayN = new int[N_PART], pTwN = new int[N_PART];

        // blink
        private final Random rnd = new Random();
        private double nextBlink = 2.0;
        private double blinkStart = -1;
        private int blinksLeft = 0;

        // parallax
        private SensorManager sm;
        private Sensor accel;
        private float baseAx = 0, baseAy = 0;
        private boolean haveBase = false;
        private float tgtX = 0, tgtY = 0, curX = 0, curY = 0;
        private float pageOffset = 0.5f;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(false);
            loadArt();
            buildMeshBase();
            Random pr = new Random(7);
            for (int i = 0; i < N_PART; i++) {
                pX[i] = pr.nextFloat();
                pY[i] = pr.nextFloat();
                pDepth[i] = 0.3f + 0.7f * pr.nextFloat();
                pRise[i] = 1 + pr.nextInt(3);          // screens per LOOP
                pSwayN[i] = 1 + pr.nextInt(4);
                pTwN[i] = 2 + pr.nextInt(5);
                pSwayA[i] = 6f + 22f * pr.nextFloat();
                pPhase[i] = (float) (pr.nextFloat() * TWO_PI);
                pTw[i] = (float) (pr.nextFloat() * TWO_PI);
            }
            sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            if (sm != null) accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

            eyePaint.setStyle(Paint.Style.FILL);
            lashPaint.setStyle(Paint.Style.STROKE);
            lashPaint.setStrokeCap(Paint.Cap.ROUND);
            lashPaint.setColor(0xFF5A3838);
            sweepPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
            glowPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
        }

        private void loadArt() {
            Bitmap src = null;
            try {
                InputStream in = getAssets().open("character.png");
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inScaled = false;
                src = BitmapFactory.decodeStream(in, null, o);
                in.close();
            } catch (Exception e) {
                // fall through
            }
            if (src == null) {
                src = Bitmap.createBitmap(SRC_W, SRC_H, Bitmap.Config.ARGB_8888);
                src.eraseColor(Color.WHITE);
            }
            if (src.getWidth() != SRC_W || src.getHeight() != SRC_H) {
                src = Bitmap.createScaledBitmap(src, SRC_W, SRC_H, true);
            }

            // Skin colour for the eyelid: average a small patch of the artwork itself.
            long r = 0, g = 0, b = 0; int n = 0;
            for (int y = SKIN_Y - 2; y <= SKIN_Y + 2; y++) {
                for (int x = SKIN_X - 2; x <= SKIN_X + 2; x++) {
                    int p = src.getPixel(x, y);
                    r += Color.red(p); g += Color.green(p); b += Color.blue(p); n++;
                }
            }
            skinColor = Color.rgb((int) (r / n), (int) (g / n), (int) (b / n));
            eyePaint.setColor(skinColor);

            // Foreground = original art with its top/bottom edge softly faded so it melts into the backdrop.
            fg = Bitmap.createBitmap(SRC_W, SRC_H, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(fg);
            cv.drawBitmap(src, 0, 0, null);
            Paint mask = new Paint();
            float f = 40f / SRC_H;
            mask.setShader(new LinearGradient(0, 0, 0, SRC_H,
                    new int[]{0x00000000, 0xFF000000, 0xFF000000, 0x00000000},
                    new float[]{0f, f, 1f - f, 1f}, Shader.TileMode.CLAMP));
            mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            cv.drawRect(0, 0, SRC_W, SRC_H, mask);

            // Backdrop = heavily blurred top / bottom edge colours of the artwork, stretched.
            Bitmap top = shrink(Bitmap.createBitmap(src, 0, 0, SRC_W, 6), 3, 1);
            Bitmap bottom = shrink(Bitmap.createBitmap(src, 0, SRC_H - 6, SRC_W, 6), 3, 1);
            bg = Bitmap.createBitmap(3, 48, Bitmap.Config.ARGB_8888);
            Canvas bc = new Canvas(bg);
            Paint bp = new Paint(Paint.FILTER_BITMAP_FLAG);
            bc.drawBitmap(top, null, new RectF(0, 0, 3, 24), bp);
            bc.drawBitmap(bottom, null, new RectF(0, 24, 3, 48), bp);

            // Soft round sprite for particles.
            sprite = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888);
            Canvas sc = new Canvas(sprite);
            Paint spp = new Paint(Paint.ANTI_ALIAS_FLAG);
            spp.setShader(new RadialGradient(32, 32, 32,
                    new int[]{0xFFFFFFFF, 0x99FFF3E4, 0x00FFF3E4}, new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
            sc.drawCircle(32, 32, 32, spp);
        }

        private Bitmap shrink(Bitmap b, int tw, int th) {
            Bitmap cur = b;
            while (cur.getWidth() > tw * 2) {
                cur = Bitmap.createScaledBitmap(cur, Math.max(tw, cur.getWidth() / 2), Math.max(th, cur.getHeight()), true);
            }
            return Bitmap.createScaledBitmap(cur, tw, th, true);
        }

        private void buildMeshBase() {
            int idx = 0;
            for (int j = 0; j <= MESH_H; j++) {
                for (int i = 0; i <= MESH_W; i++) {
                    float x = SRC_W * i / (float) MESH_W;
                    float y = SRC_H * j / (float) MESH_H;
                    baseX[idx] = x;
                    baseY[idx] = y;
                    for (int z = 0; z < ZONES.length; z++) {
                        Zone zn = ZONES[z];
                        float dx = x - zn.cx, dy = y - zn.cy;
                        float w = (float) Math.exp(-(dx * dx + dy * dy) / (2f * zn.sigma * zn.sigma));
                        weights[z][idx] = w < 0.01f ? 0f : w;
                    }
                    idx++;
                }
            }
        }

        // ---------------- lifecycle ----------------

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            W = width; H = height;
            readPrefs();

            RadialGradient glow = new RadialGradient(W * 0.85f, H * 0.12f, W * 0.8f,
                    0x38FFE6C0, 0x00FFE6C0, Shader.TileMode.CLAMP);
            glowPaint.setShader(glow);

            sweepBandW = W * 0.7f;
            sweepShader = new LinearGradient(0, 0, sweepBandW, 0,
                    new int[]{0x00FFFFFF, 0x26FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
            sweepPaint.setShader(sweepShader);
        }

        @Override
        public void onVisibilityChanged(boolean vis) {
            visible = vis;
            if (vis) {
                readPrefs();
                haveBase = false;
                if (sm != null && accel != null) sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);
                Choreographer.getInstance().removeFrameCallback(frameCb);
                Choreographer.getInstance().postFrameCallback(frameCb);
            } else {
                Choreographer.getInstance().removeFrameCallback(frameCb);
                if (sm != null) sm.unregisterListener(this);
            }
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            Choreographer.getInstance().removeFrameCallback(frameCb);
            if (sm != null) sm.unregisterListener(this);
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            visible = false;
            Choreographer.getInstance().removeFrameCallback(frameCb);
            if (sm != null) sm.unregisterListener(this);
            super.onDestroy();
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xStep, float yStep, int xPixels, int yPixels) {
            pageOffset = xOffset;
        }

        private void readPrefs() {
            SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            mode = sp.getInt(KEY_MODE, 1);
        }

        // ---------------- sensors ----------------

        @Override
        public void onSensorChanged(SensorEvent e) {
            float ax = -e.values[0] / 9.81f;
            float ay = e.values[1] / 9.81f;
            if (!haveBase) { baseAx = ax; baseAy = ay; haveBase = true; }
            // slowly re-centre so any resting angle becomes "neutral"
            baseAx += (ax - baseAx) * 0.01f;
            baseAy += (ay - baseAy) * 0.01f;
            tgtX = clamp((ax - baseAx) * 2.2f, -1f, 1f);
            tgtY = clamp((ay - baseAy) * 2.2f, -1f, 1f);
        }

        @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

        private float clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

        // ---------------- drawing ----------------

        private void drawFrame() {
            if (W == 0 || H == 0) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                try {
                    c = useHwCanvas ? holder.lockHardwareCanvas() : holder.lockCanvas();
                } catch (Exception ex) {
                    useHwCanvas = false;
                    c = holder.lockCanvas();
                }
                if (c != null) render(c);
            } catch (Exception ignored) {
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (Exception ignored) { }
                }
            }
        }

        private void render(Canvas c) {
            double real = (SystemClock.uptimeMillis() - t0) / 1000.0;
            double t = real % LOOP;
            float k = (float) (t / LOOP);

            // --- parallax target: tilt + launcher page offset + a faint idle drift (keeps depth visible) ---
            float idle = 0.25f * (float) Math.sin(TWO_PI * 2 * k);
            float idleY = 0.15f * (float) Math.sin(TWO_PI * 3 * k + 1f);
            float tx = clamp(tgtX + idle + (pageOffset - 0.5f) * 1.2f, -1f, 1f);
            float ty = clamp(tgtY + idleY, -1f, 1f);
            curX += (tx - curX) * 0.08f;
            curY += (ty - curY) * 0.08f;
            float amp = W * 0.02f;

            // --- backdrop ---
            RectF bgDst = new RectF(-0.04f * W + curX * amp * 0.4f, -0.02f * H + curY * amp * 0.3f,
                    1.04f * W + curX * amp * 0.4f, 1.02f * H + curY * amp * 0.3f);
            c.drawBitmap(bg, null, bgDst, bgPaint);

            // --- layout of the character layer ---
            float baseS = W / (float) SRC_W;
            float s, offX, offY;
            float margin = 0.03f * W;
            if (mode == 1) {                       // zoom: portrait crop that slowly pans across the art
                s = baseS * 1.9f * 1.06f;
                float centerX = 255f + 90f * (float) Math.sin(TWO_PI * k);
                offX = W / 2f - centerX * s;
                float minX = W - SRC_W * s + margin, maxX = -margin;
                offX = clamp(offX, minX, maxX);
            } else {                               // fit: whole illustration, slightly oversized for parallax room
                s = baseS * 1.06f;
                offX = (W - SRC_W * s) / 2f;
            }
            offY = (H - SRC_H * s) / 2f;
            offX += curX * amp * 0.9f;
            offY += curY * amp * 0.55f;

            // --- hair / ribbon / pill sway via mesh warp ---
            for (int z = 0; z < ZONES.length; z++) {
                Zone zn = ZONES[z];
                double a = TWO_PI * zn.cycles * k + zn.phase;
                zdx[z] = zn.ampX * (float) Math.sin(a);
                zdy[z] = zn.ampY * (float) Math.sin(a + 1.3);
            }
            int count = baseX.length;
            for (int v = 0; v < count; v++) {
                float dx = 0f, dy = 0f;
                for (int z = 0; z < ZONES.length; z++) {
                    float w = weights[z][v];
                    if (w != 0f) { dx += w * zdx[z]; dy += w * zdy[z]; }
                }
                verts[v * 2] = offX + (baseX[v] + dx) * s;
                verts[v * 2 + 1] = offY + (baseY[v] + dy) * s;
            }
            c.drawBitmapMesh(fg, MESH_W, MESH_H, verts, 0, null, 0, fgPaint);

            // --- blink (drawn in artwork space; eye area is not warped) ---
            float closed = blinkAmount(real);
            if (closed > 0.02f) {
                c.save();
                c.translate(offX, offY);
                c.scale(s, s);
                c.translate(EYE_X, EYE_Y);
                c.rotate(EYE_TILT);
                Path clip = new Path();
                clip.addOval(new RectF(-EYE_A, -EYE_B, EYE_A, EYE_B), Path.Direction.CW);
                c.save();
                c.clipPath(clip);
                float edge = -EYE_B + closed * 2f * EYE_B;
                c.drawRect(-EYE_A - 1, -EYE_B - 1, EYE_A + 1, edge, eyePaint);
                c.restore();
                lashPaint.setStrokeWidth(1.5f);
                lashPaint.setAlpha((int) (255 * Math.min(1f, closed * 1.6f)));
                Path lash = new Path();
                lash.moveTo(-EYE_A, edge);
                lash.quadTo(0, edge + 2.5f * closed, EYE_A, edge);
                c.drawPath(lash, lashPaint);
                c.restore();
            }

            // --- atmosphere: warm glow + slow light sweep ---
            float glowA = 0.55f + 0.45f * (float) Math.sin(TWO_PI * 3 * k);
            glowPaint.setAlpha((int) (255 * (0.4f + 0.6f * glowA)));
            c.drawRect(0, 0, W, H, glowPaint);

            float sweepX = -sweepBandW + (W + sweepBandW) * k;
            sweepMatrix.setTranslate(sweepX, 0);
            sweepShader.setLocalMatrix(sweepMatrix);
            c.save();
            c.rotate(-18f, W / 2f, H / 2f);
            c.drawRect(-W, -H / 2f, 2f * W, 1.5f * H, sweepPaint);
            c.restore();

            // --- floating particles ---
            float unit = W / 720f;
            RectF r = new RectF();
            for (int i = 0; i < N_PART; i++) {
                float rise = (pY[i] + pRise[i] * k) % 1f;
                float yF = 1f - rise;
                float x = pX[i] * W + pSwayA[i] * unit * (float) Math.sin(TWO_PI * pSwayN[i] * k + pPhase[i])
                        + curX * amp * 2.2f * pDepth[i];
                float y = yF * H + curY * amp * 1.2f * pDepth[i];
                float size = (5f + 15f * pDepth[i]) * unit;
                float edgeFade = Math.min(1f, Math.min(yF, 1f - yF) / 0.12f);
                float tw = 0.5f + 0.5f * (float) Math.sin(TWO_PI * pTwN[i] * k + pTw[i]);
                int alpha = (int) (255 * edgeFade * (0.12f + 0.5f * tw) * (0.5f + 0.5f * pDepth[i]));
                partPaint.setAlpha(Math.max(0, Math.min(255, alpha)));
                r.set(x - size, y - size, x + size, y + size);
                c.drawBitmap(sprite, null, r, partPaint);
            }
        }

        /** 0 = open, 1 = fully closed. Random, natural-looking blinks, sometimes a quick double blink. */
        private float blinkAmount(double now) {
            if (blinkStart < 0 && now >= nextBlink) {
                blinkStart = now;
                if (blinksLeft == 0 && rnd.nextFloat() < 0.18f) blinksLeft = 1;
            }
            if (blinkStart >= 0) {
                double u = (now - blinkStart) / 0.17;
                if (u >= 1.0) {
                    blinkStart = -1;
                    if (blinksLeft > 0) { blinksLeft--; nextBlink = now + 0.12; }
                    else nextBlink = now + 2.5 + rnd.nextFloat() * 4.0;
                    return 0f;
                }
                return (float) Math.sin(Math.PI * u);
            }
            return 0f;
        }
    }
}
