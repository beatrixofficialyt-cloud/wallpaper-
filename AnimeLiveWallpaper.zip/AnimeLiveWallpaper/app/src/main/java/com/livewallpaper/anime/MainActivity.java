package com.livewallpaper.anime;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

/** Tiny launcher / settings screen: pick a framing and open the system "set live wallpaper" preview. */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final SharedPreferences sp = getSharedPreferences(AnimeWallpaperService.PREFS, Context.MODE_PRIVATE);
        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (24 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("Anime Live Wallpaper");
        title.setTextSize(24);
        title.setTextColor(Color.BLACK);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Framing");
        sub.setTextColor(0xFF555555);
        sub.setPadding(0, pad, 0, (int) (8 * d));
        root.addView(sub);

        RadioGroup group = new RadioGroup(this);
        RadioButton fit = new RadioButton(this);
        fit.setText("Fit - whole illustration, softly blended into the backdrop");
        fit.setId(View.generateViewId());
        RadioButton zoom = new RadioButton(this);
        zoom.setText("Zoom - closer on the character, slowly panning");
        zoom.setId(View.generateViewId());
        group.addView(fit);
        group.addView(zoom);
        group.check(sp.getInt(AnimeWallpaperService.KEY_MODE, 1) == 1 ? zoom.getId() : fit.getId());
        final int zoomId = zoom.getId();
        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup g, int checkedId) {
                sp.edit().putInt(AnimeWallpaperService.KEY_MODE, checkedId == zoomId ? 1 : 0).apply();
            }
        });
        root.addView(group);

        Button set = new Button(this);
        set.setText("Set as live wallpaper");
        set.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                    i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            new ComponentName(MainActivity.this, AnimeWallpaperService.class));
                    startActivity(i);
                } catch (Exception e) {
                    startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
                }
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = pad;
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(set, lp);

        setContentView(root);
    }
}
