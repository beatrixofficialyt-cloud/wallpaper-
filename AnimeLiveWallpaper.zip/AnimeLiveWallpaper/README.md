# Anime Live Wallpaper

A real Android live wallpaper (`WallpaperService`) built around your illustration (`app/src/main/assets/character.png`, your upload with its black letterbox bars removed).

## Build the APK (about 5 minutes)

1. Install [Android Studio](https://developer.android.com/studio) and open this folder (`AnimeLiveWallpaper`). Let it sync (it downloads the SDK and Gradle for you).
2. Menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. The APK lands in `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it (allow "install unknown apps" if asked).
4. Open the **Anime Live Wallpaper** app, pick a framing, tap **Set as live wallpaper**, then **Set wallpaper**.

Command line instead: with the Android SDK installed and `ANDROID_HOME` set, run `gradle assembleDebug` (Gradle 8.7+).

## What it does

- Hair tips, the ahoge, the bow and ribbon tails, and the loose pills sway gently. This is a mesh warp of the original pixels; nothing is redrawn or regenerated.
- Occasional natural blink (random timing, sometimes a quick double blink). The eyelid patch takes its colour from the artwork's own skin.
- Soft floating particles, a warm breathing glow, and a faint slow light sweep.
- Tilt parallax: backdrop, character and particles shift by different amounts. A faint idle drift keeps depth visible even when the phone is still.
- Renders every display frame (60 FPS, or 90/120 Hz on high-refresh screens) with a hardware canvas, and pauses when the wallpaper is not visible.
- All periodic motion repeats every 24 s with whole cycles, so there is no loop seam.

## Tuning

Everything is in `AnimeWallpaperService.java`:

- `ZONES` - where and how much things sway (artwork pixel coordinates, 640x358). Raise `ampX`/`ampY` for more movement.
- `EYE_X, EYE_Y, EYE_A, EYE_B` - blink position and size.
- Particle count `N_PART`, glow/sweep alpha values in `onSurfaceChanged`.
- Parallax strength: `float amp = W * 0.02f;`

To use a different image, replace `assets/character.png` (keep 640x358, or update `SRC_W`/`SRC_H`) and re-aim `ZONES` and the eye values.

## No PC? Build on GitHub from your phone

1. Create a free GitHub account and a new empty repository.
2. In the repo, use **Add file > Upload files** and upload the *contents* of this folder (including the hidden `.github` folder; if your phone can't pick it, create the file `.github/workflows/build.yml` via **Add file > Create new file** and paste its contents).
3. Open the **Actions** tab, choose **Build APK**, tap **Run workflow**.
4. When it finishes (about 5 min), open the run and download the **AnimeLiveWallpaper-apk** artifact, unzip it, and install `app-debug.apk`.
